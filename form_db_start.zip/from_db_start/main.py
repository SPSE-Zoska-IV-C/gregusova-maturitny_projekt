from flask import Flask
from flask import render_template

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/clanky')
def clanky():
    return render_template('clanky.html')

@app.route('/onas')
def onas():
    return render_template('onas.html')

@app.route('/profil')
def profil():
    return render_template('profil.html')